package mx.com.softgame.poo1game.personajes.malos;
import mx.com.softgame.poo1game.personajes.malos.Zombie;
public class Zombiecono extends Zombie{
    public Zombiecono(String nombre){
        super(nombre);
    }
    //la clase Zombie es final no se puede heredar de ella
}