package mx.com.softgame.poo1game.pruebas;
import mx.com.softgame.poo1game.tipo.Vehiculo;
import mx.com.softgame.poo1game.tipo.Taxi;
import mx.com.softgame.poo1game.tipo.Autobus;
public class Prueba{
    public static void main(String[]args){
      Vehiculo v1 = new Vehiculo ("str",10);
      Taxi t1 = new Taxi("stee",1,"fff");
      Autobus a1 = new Autobus("sgg",2,8);
      System.out.println(v1.getDetalle());
      System.out.println(t1.getDetalle());
      System.out.println(a1.getDetalle());
    }
}