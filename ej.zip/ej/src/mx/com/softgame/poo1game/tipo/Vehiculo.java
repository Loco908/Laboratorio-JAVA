package mx.com.softgame.poo1game.tipo;
public class Vehiculo{
    private String matricula;
    private int modelo; 
    public Vehiculo(String matricula,int modelo){
        this.matricula = matricula;
        this.modelo= modelo; 
    }
    public void setModelo(int modelo){
        if(modelo>=1)
        {
         modelo = 2019;

        }
    }
    public int getModelo(){
        return modelo;
    }
    public void setMatricula(){
        
    }
    public String getMatricula(){
        return matricula;
    }
    public String getDetalle(){
        return matricula+"\t"+modelo; 
    }

   



}