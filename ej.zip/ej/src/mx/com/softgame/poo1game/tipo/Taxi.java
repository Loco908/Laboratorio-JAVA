package mx.com.softgame.poo1game.tipo;
import mx.com.softgame.poo1game.tipo.Vehiculo;

public class Taxi extends Vehiculo{
    private String noLicencia;
    public Taxi(String matricula,int modelo,String noLicencia){
        super(matricula,modelo);
        this.noLicencia = noLicencia; 
    }
    public void setNoLicencia(String lic){
        if(lic=="Ninguno")
        {
          noLicencia = "Ninguno";
        }
    }
    public String getnoLicencia(){
        return noLicencia;
    }
    
    public String getDetalle(){
        return super.getDetalle()+""+noLicencia;
    }
    


}