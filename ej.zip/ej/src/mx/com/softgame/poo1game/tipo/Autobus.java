package mx.com.softgame.poo1game.tipo;
import mx.com.softgame.poo1game.tipo.Vehiculo;
public class Autobus extends Vehiculo{
    private int numAsientos;
    public Autobus(String matricula,int modelo,int numAsientos){
        super(matricula,modelo);
        this.numAsientos = numAsientos; 
    }
    public void setNumAsientos(int as){
        if(as<10)
        {
          numAsientos = 0;
        }
    }
    public int getNumAsientos(){
        return numAsientos;
    }
    public String getDetalle(){
        return super.getDetalle()+""+numAsientos;
    }
    


}