public class PruebaAlumno {
    public static void main(String[] args) {
        int[] calificaciones = new calificaciones[5];
        Alumnos[0].setCalificacion(100);
    }
}
