package mx.com.softgame.poo1game.pruebas;
import mx.com.softgame.poo1game.ventanas.VentanaHilo;
public class PruebaHilos {
    public static void main(String[] args) {
        VentanaHilo vh = new VentanaHilo();
        vh.setVisible(true);   
    }
    
}
