public class Utileria {
    int contadorID;

    public static int getId(int contadorId) {
        int contadorID;
        contadorID(++contadorId);

    }

}
