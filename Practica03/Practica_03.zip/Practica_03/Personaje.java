//Luis Eduardo
//Hora de inicio: 8:00
//hora de terminado: 8:30

public class Personaje{
    private int edad;
    private String nombre;


    public void setNombre( String nombre){
        this.nombre = nombre;
    }

    public String getNombre(){
        return nombre;
    }

    public void saludar(){
        System.out.println("Hola Alumno de POO" +"    "+  nombre);
    }
}